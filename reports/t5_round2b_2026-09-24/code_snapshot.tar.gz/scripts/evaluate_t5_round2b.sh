#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/SelfJev"
export PYTHONPATH=src
export OMP_NUM_THREADS=4
export HF_HUB_DISABLE_PROGRESS_BARS=1
P=.venv/bin/python
# Wait for the validated selected adapter, not merely an intermediate checkpoint.
while [ ! -f runs/t5gemma2_r2b/train_meta.json ]; do
  if ! pgrep -f '^.venv/bin/python scripts/train_t5_round2b.py$' >/dev/null; then
    echo 'Training exited without verified final metadata'; exit 1
  fi
  sleep 30
done
$P scripts/eval_t5_round2b.py t5_r2b
$P scripts/eval_t5_round2b.py t5_r1
$P scripts/eval_t5_round2b.py t5_r2b_merged
$P scripts/eval_t5_round2b.py t5_r2b_merged_b48
$P scripts/eval_t5_round2b.py tree_r2b
$P scripts/eval_t5_round2b.py tree_r2b_merged
$P -m personal_jev.vllm_tree merge --adapter runs/tree_4b_r2b/adapter --out runs/tree_4b_r2b/merged
.venv-vllm/bin/python scripts/eval_t5_round2b.py tree_r2b_vllm
.venv-vllm/bin/python scripts/eval_t5_round2b.py tree_r2b_vllm_fp8
$P scripts/check_t5_overfit.py
$P scripts/profile_t5_round2b.py
$P scripts/summarize_t5_round2b.py
printf 'COMPARISON_COMPLETE\n'
